package com.example.disasterresponseapp10

data class ContactInfo(
    val phoneNumber: String,
    val email: String
)