package com.example.disasterresponseapp10

data class EmergencyContact(
    val name: String,
    val relationship: String,  // E.g., "Father", "Friend"
    val phoneNumber: String
)